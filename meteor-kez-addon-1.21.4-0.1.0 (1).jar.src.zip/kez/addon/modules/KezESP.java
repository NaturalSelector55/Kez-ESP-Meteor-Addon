/*     */ package kez.addon.modules;
/*     */ import kez.addon.KezAddon;
/*     */ import meteordevelopment.meteorclient.events.render.Render3DEvent;
/*     */ import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
/*     */ import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
/*     */ import meteordevelopment.meteorclient.renderer.ShapeMode;
/*     */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*     */ import meteordevelopment.meteorclient.settings.ColorSetting;
/*     */ import meteordevelopment.meteorclient.settings.EnumSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.meteorclient.utils.Utils;
/*     */ import meteordevelopment.meteorclient.utils.render.color.Color;
/*     */ import meteordevelopment.meteorclient.utils.render.color.SettingColor;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2741;
/*     */ import net.minecraft.class_2769;
/*     */ import net.minecraft.class_2791;
/*     */ 
/*     */ public class KezESP extends Module {
/*  26 */   private final SettingGroup sgRender = this.settings.createGroup("Render");
/*     */   
/*  28 */   private final Setting<SettingColor> espColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder())
/*  29 */       .name("esp-color"))
/*  30 */       .description("ESP box color."))
/*  31 */       .defaultValue(new SettingColor(255, 0, 255, 100))
/*  32 */       .build());
/*     */ 
/*     */   
/*  35 */   private final Setting<ShapeMode> shapeMode = this.sgRender.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/*  36 */       .name("shape-mode"))
/*  37 */       .description("Box render mode."))
/*  38 */       .defaultValue(ShapeMode.Both))
/*  39 */       .build());
/*     */ 
/*     */   
/*  42 */   private final Setting<Boolean> chatFeedback = this.sgRender.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  43 */       .name("chat-feedback"))
/*  44 */       .description("Announce detections in chat."))
/*  45 */       .defaultValue(Boolean.valueOf(true)))
/*  46 */       .build());
/*     */ 
/*     */ 
/*     */   
/*  50 */   private final Set<class_2338> rotatedDeepslate = new HashSet<>();
/*     */   
/*     */   public KezESP() {
/*  53 */     super(KezAddon.CATEGORY, "kez-esp", "ESP for rotated deepslate (player placed");
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   private void onChunkLoad(ChunkDataEvent event) {
/*  59 */     scanChunk((class_2791)event.chunk());
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   private void onBlockUpdate(BlockUpdateEvent event) {
/*  65 */     class_2338 pos = event.pos;
/*  66 */     class_2680 state = event.newState;
/*  67 */     boolean isRotated = isRotatedDeepslate(state, pos.method_10264());
/*     */     
/*  69 */     if (isRotated && this.rotatedDeepslate.add(pos)) {
/*  70 */       if (((Boolean)this.chatFeedback.get()).booleanValue()) info("§dKezESP§f: Rotated deepslate at §a" + pos.method_23854(), new Object[0]); 
/*  71 */     } else if (!isRotated) {
/*  72 */       this.rotatedDeepslate.remove(pos);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void scanChunk(class_2791 chunk) {
/*  78 */     int xStart = chunk.method_12004().method_8326();
/*  79 */     int zStart = chunk.method_12004().method_8328();
/*  80 */     int yMin = chunk.method_31607();
/*  81 */     int yMax = Math.min(128, yMin + chunk.method_31605());
/*     */     
/*  83 */     for (int x = xStart; x < xStart + 16; x++) {
/*  84 */       for (int z = zStart; z < zStart + 16; z++) {
/*  85 */         for (int y = yMin; y < yMax; y++) {
/*  86 */           class_2338 pos = new class_2338(x, y, z);
/*  87 */           if (isRotatedDeepslate(chunk.method_8320(pos), y) && 
/*  88 */             this.rotatedDeepslate.add(pos) && ((Boolean)this.chatFeedback.get()).booleanValue()) {
/*  89 */             info("§dKezESP§f: Rotated deepslate at §a" + pos.method_23854(), new Object[0]);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isRotatedDeepslate(class_2680 state, int y) {
/*  99 */     return (y < 128 && state
/* 100 */       .method_26204() == class_2246.field_28888 && state
/* 101 */       .method_28498((class_2769)class_2741.field_12496) && state
/* 102 */       .method_11654((class_2769)class_2741.field_12496) != class_2350.class_2351.field_11052);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onActivate() {
/* 108 */     this.rotatedDeepslate.clear();
/* 109 */     if (this.mc.field_1687 == null)
/* 110 */       return;  for (class_2791 chunk : Utils.chunks()) {
/* 111 */       scanChunk(chunk);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onRender(Render3DEvent event) {
/* 117 */     Color sideColor = new Color((Color)this.espColor.get());
/* 118 */     Color lineColor = new Color((Color)this.espColor.get());
/*     */     
/* 120 */     for (class_2338 pos : this.rotatedDeepslate)
/* 121 */       event.renderer.box(pos, sideColor, lineColor, (ShapeMode)this.shapeMode.get(), 0); 
/*     */   }
/*     */ }


/* Location:              C:\Users\kunna\Downloads\meteor-kez-addon-1.21.4-0.1.0 (1).jar!\kez\addon\modules\KezESP.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */