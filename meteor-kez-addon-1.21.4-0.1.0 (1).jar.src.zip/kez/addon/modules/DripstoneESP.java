/*     */ package kez.addon.modules;
/*     */ import meteordevelopment.meteorclient.events.render.Render3DEvent;
/*     */ import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
/*     */ import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
/*     */ import meteordevelopment.meteorclient.renderer.ShapeMode;
/*     */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*     */ import meteordevelopment.meteorclient.settings.ColorSetting;
/*     */ import meteordevelopment.meteorclient.settings.EnumSetting;
/*     */ import meteordevelopment.meteorclient.settings.IntSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.meteorclient.utils.Utils;
/*     */ import meteordevelopment.meteorclient.utils.render.color.Color;
/*     */ import meteordevelopment.meteorclient.utils.render.color.SettingColor;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2741;
/*     */ import net.minecraft.class_2769;
/*     */ import net.minecraft.class_2791;
/*     */ 
/*     */ public class DripstoneESP extends Module {
/*  25 */   private final SettingGroup sgRender = this.settings.createGroup("Render");
/*     */   
/*  27 */   private final Setting<SettingColor> espColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder())
/*  28 */       .name("esp-color"))
/*  29 */       .description("ESP box color."))
/*  30 */       .defaultValue(new SettingColor(100, 255, 200, 100))
/*  31 */       .build());
/*     */ 
/*     */   
/*  34 */   private final Setting<ShapeMode> shapeMode = this.sgRender.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/*  35 */       .name("shape-mode"))
/*  36 */       .description("Box render mode."))
/*  37 */       .defaultValue(ShapeMode.Both))
/*  38 */       .build());
/*     */ 
/*     */   
/*  41 */   private final Setting<Boolean> chatFeedback = this.sgRender.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  42 */       .name("chat-feedback"))
/*  43 */       .description("Announce detections in chat."))
/*  44 */       .defaultValue(Boolean.valueOf(true)))
/*  45 */       .build());
/*     */ 
/*     */   
/*  48 */   private final Setting<Integer> minLength = this.sgRender.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  49 */       .name("min-length"))
/*  50 */       .description("Minimum length for stalactites to ESP highlight."))
/*  51 */       .defaultValue(Integer.valueOf(8)))
/*  52 */       .min(4)
/*  53 */       .max(8)
/*  54 */       .sliderRange(4, 8)
/*  55 */       .build());
/*     */ 
/*     */ 
/*     */   
/*  59 */   private final Set<class_2338> longDripstoneTips = new HashSet<>();
/*     */   
/*     */   public DripstoneESP() {
/*  62 */     super(KezAddon.CATEGORY, "dripstone-esp", "ESP for downward dripstone growth with configurable minimum length (4-8).");
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onChunkLoad(ChunkDataEvent event) {
/*  67 */     scanChunk((class_2791)event.chunk());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onBlockUpdate(BlockUpdateEvent event) {
/*  72 */     class_2338 pos = event.pos;
/*  73 */     class_2680 state = event.newState;
/*     */     
/*  75 */     if (isDripstoneTipDown(state)) {
/*  76 */       int len = getStalactiteLength(pos);
/*  77 */       if (len >= ((Integer)this.minLength.get()).intValue()) {
/*  78 */         if (this.longDripstoneTips.add(pos) && ((Boolean)this.chatFeedback.get()).booleanValue()) {
/*  79 */           info("Long dripstone at " + pos.method_23854() + " (length " + len + ")", new Object[0]);
/*     */         }
/*     */       } else {
/*  82 */         this.longDripstoneTips.remove(pos);
/*     */       } 
/*     */     } else {
/*  85 */       this.longDripstoneTips.remove(pos);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void scanChunk(class_2791 chunk) {
/*  90 */     int xStart = chunk.method_12004().method_8326();
/*  91 */     int zStart = chunk.method_12004().method_8328();
/*  92 */     int yMin = chunk.method_31607();
/*  93 */     int yMax = yMin + chunk.method_31605();
/*     */     
/*  95 */     for (int x = xStart; x < xStart + 16; x++) {
/*  96 */       for (int z = zStart; z < zStart + 16; z++) {
/*  97 */         for (int y = yMin; y < yMax; y++) {
/*  98 */           class_2338 pos = new class_2338(x, y, z);
/*  99 */           class_2680 state = chunk.method_8320(pos);
/*     */           
/* 101 */           if (isDripstoneTipDown(state)) {
/* 102 */             int len = getStalactiteLength(pos);
/* 103 */             if (len >= ((Integer)this.minLength.get()).intValue() && 
/* 104 */               this.longDripstoneTips.add(pos) && ((Boolean)this.chatFeedback.get()).booleanValue()) {
/* 105 */               info("Long stalactite at " + pos.method_23854() + " (length " + len + ")", new Object[0]);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isDripstoneTipDown(class_2680 state) {
/* 116 */     return (state.method_26204() == class_2246.field_28048 && state
/* 117 */       .method_11654((class_2769)class_2741.field_28062) == class_2350.field_11033);
/*     */   }
/*     */ 
/*     */   
/*     */   private int getStalactiteLength(class_2338 tip) {
/* 122 */     if (this.mc.field_1687 == null) return 0; 
/* 123 */     int length = 0;
/* 124 */     class_2338 scan = tip;
/*     */     while (true) {
/* 126 */       class_2680 state = this.mc.field_1687.method_8320(scan);
/* 127 */       if (state.method_26204() == class_2246.field_28048 && state
/* 128 */         .method_11654((class_2769)class_2741.field_28062) == class_2350.field_11033) {
/* 129 */         length++;
/* 130 */         scan = scan.method_10084();
/*     */         continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 135 */     return length;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onActivate() {
/* 140 */     this.longDripstoneTips.clear();
/* 141 */     if (this.mc.field_1687 == null)
/* 142 */       return;  for (class_2791 chunk : Utils.chunks()) {
/* 143 */       scanChunk(chunk);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onRender(Render3DEvent event) {
/* 149 */     Color sideColor = new Color((Color)this.espColor.get());
/* 150 */     Color lineColor = new Color((Color)this.espColor.get());
/*     */     
/* 152 */     for (class_2338 pos : this.longDripstoneTips)
/* 153 */       event.renderer.box(pos, sideColor, lineColor, (ShapeMode)this.shapeMode.get(), 0); 
/*     */   }
/*     */ }


/* Location:              C:\Users\kunna\Downloads\meteor-kez-addon-1.21.4-0.1.0 (1).jar!\kez\addon\modules\DripstoneESP.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */