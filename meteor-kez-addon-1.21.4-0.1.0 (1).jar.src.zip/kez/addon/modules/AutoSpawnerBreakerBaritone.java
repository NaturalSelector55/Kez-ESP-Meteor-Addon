/*     */ package kez.addon.modules;
/*     */ 
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.util.UUID;
/*     */ import kez.addon.KezAddon;
/*     */ import meteordevelopment.meteorclient.events.entity.EntityAddedEvent;
/*     */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*     */ import meteordevelopment.meteorclient.settings.IntSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*     */ import meteordevelopment.meteorclient.settings.StringSetting;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.meteorclient.utils.player.ChatUtils;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2374;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2661;
/*     */ import net.minecraft.class_2848;
/*     */ import net.minecraft.class_304;
/*     */ import net.minecraft.class_745;
/*     */ 
/*     */ public class AutoSpawnerBreakerBaritone extends Module {
/*  30 */   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
/*     */   
/*  32 */   private final Setting<String> webhookUrl = this.sgGeneral.add((Setting)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder())
/*  33 */       .name("webhook-url"))
/*  34 */       .description("Discord webhook to notify when disconnecting."))
/*  35 */       .defaultValue(""))
/*  36 */       .build());
/*     */ 
/*     */   
/*  39 */   private final Setting<Integer> delaySeconds = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*  40 */       .name("recheck-delay-seconds"))
/*  41 */       .description("Delay in seconds before rechecking for spawners."))
/*  42 */       .defaultValue(Integer.valueOf(1)))
/*  43 */       .min(1)
/*  44 */       .sliderMax(10)
/*  45 */       .build());
/*     */   
/*     */   private boolean triggered = false;
/*     */   
/*     */   private boolean sneaking = false;
/*  50 */   private class_2338 currentTarget = null;
/*  51 */   private int recheckDelay = 0;
/*  52 */   private int confirmDelay = 0;
/*     */   private boolean waiting = false;
/*  54 */   private String detectedPlayer = null;
/*     */   
/*     */   public AutoSpawnerBreakerBaritone() {
/*  57 */     super(KezAddon.CATEGORY, "spawner-protect", "Crouches, breaks spawners, and alerts discord webhook.");
/*     */   }
/*     */ 
/*     */   
/*     */   public void onActivate() {
/*  62 */     this.triggered = false;
/*  63 */     this.sneaking = false;
/*  64 */     this.currentTarget = null;
/*  65 */     this.recheckDelay = 0;
/*  66 */     this.confirmDelay = 0;
/*  67 */     this.waiting = false;
/*  68 */     this.detectedPlayer = null;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onEntityAdded(EntityAddedEvent event) {
/*  73 */     if (!this.triggered) { class_1297 class_1297 = event.entity; if (class_1297 instanceof class_745) { class_745 player = (class_745)class_1297;
/*  74 */         this.triggered = true;
/*  75 */         this.detectedPlayer = player.method_5477().getString();
/*  76 */         ChatUtils.info("Player near spawners: " + this.detectedPlayer, new Object[0]); }
/*     */        }
/*     */   
/*     */   }
/*     */   @EventHandler
/*     */   private void onTick(TickEvent.Post event) {
/*  82 */     if (!this.triggered || this.mc.field_1724 == null || this.mc.field_1687 == null || this.mc.field_1761 == null)
/*     */       return; 
/*  84 */     if (!this.sneaking) {
/*  85 */       this.mc.field_1724.method_5660(true);
/*  86 */       this.mc.method_1562().method_52787((class_2596)new class_2848((class_1297)this.mc.field_1724, class_2848.class_2849.field_12979));
/*  87 */       this.sneaking = true;
/*     */     } 
/*     */     
/*  90 */     if (this.currentTarget == null) {
/*  91 */       class_2338 origin = this.mc.field_1724.method_24515();
/*  92 */       for (class_2338 pos : class_2338.method_10097(origin.method_10069(-6, -3, -6), origin.method_10069(6, 3, 6))) {
/*  93 */         if (this.mc.field_1687.method_8320(pos).method_26204() == class_2246.field_10260 && pos
/*  94 */           .method_19770((class_2374)this.mc.field_1724.method_19538()) < 26.0D) {
/*  95 */           this.currentTarget = pos.method_10062();
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 100 */       if (this.currentTarget == null && !this.waiting) {
/* 101 */         this.waiting = true;
/* 102 */         this.recheckDelay = 0;
/* 103 */         this.confirmDelay = 0;
/*     */       } 
/*     */     } else {
/* 106 */       this.mc.field_1761.method_2902(this.currentTarget, class_2350.field_11036);
/* 107 */       class_304.method_1416(this.mc.field_1690.field_1886.method_1429(), true);
/*     */       
/* 109 */       if (this.mc.field_1687.method_8320(this.currentTarget).method_26215()) {
/* 110 */         this.currentTarget = null;
/* 111 */         class_304.method_1416(this.mc.field_1690.field_1886.method_1429(), false);
/*     */       } 
/*     */     } 
/*     */     
/* 115 */     if (this.waiting) {
/* 116 */       this.recheckDelay++;
/* 117 */       if (this.recheckDelay == ((Integer)this.delaySeconds.get()).intValue() * 20) {
/* 118 */         boolean foundAgain = false;
/* 119 */         class_2338 origin = this.mc.field_1724.method_24515();
/* 120 */         for (class_2338 pos : class_2338.method_10097(origin.method_10069(-6, -3, -6), origin.method_10069(6, 3, 6))) {
/* 121 */           if (this.mc.field_1687.method_8320(pos).method_26204() == class_2246.field_10260) {
/* 122 */             foundAgain = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 127 */         if (foundAgain) {
/* 128 */           this.waiting = false;
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/* 133 */       if (this.recheckDelay > ((Integer)this.delaySeconds.get()).intValue() * 20) {
/* 134 */         this.confirmDelay++;
/* 135 */         if (this.confirmDelay >= 20) {
/* 136 */           class_304.method_1416(this.mc.field_1690.field_1886.method_1429(), false);
/* 137 */           if (!((String)this.webhookUrl.get()).isEmpty()) sendFancyWebhook(); 
/* 138 */           this.mc.field_1724.field_3944.method_52781(new class_2661(
/* 139 */                 (class_2561)class_2561.method_43470("§7[§cA player was nearby your SPAWNERS§7] A player was nearby your SPAWNERS")));
/*     */           
/* 141 */           toggle();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void sendFancyWebhook() {
/*     */     try {
/* 149 */       UUID uuid = this.mc.method_1548().method_44717();
/* 150 */       String stealerName = this.mc.method_1548().method_1676();
/* 151 */       String stealerAvatar = (uuid != null) ? ("https://crafatar.com/avatars/" + String.valueOf(uuid) + "?overlay") : "";
/*     */       
/* 153 */       String detectedAvatar = (this.detectedPlayer != null) ? ("https://minotar.net/avatar/" + this.detectedPlayer + "/100.png") : "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 173 */       String payload = "{\n  \"username\": \"Spawner Alert\",\n  \"avatar_url\": \"%s\",\n  \"embeds\": [\n    {\n      \"title\": \"**%s** broke all spawners and left!\",\n      \"description\": \"Nearby player: **%s**\",\n      \"color\": 15548997,\n      \"thumbnail\": {\n        \"url\": \"%s\"\n      },\n      \"footer\": {\n        \"text\": \"SpawnerProtect\"\n      }\n    }\n  ]\n}\n".formatted(new Object[] { stealerAvatar, stealerName, (this.detectedPlayer == null) ? "Unknown" : this.detectedPlayer, detectedAvatar });
/*     */       
/* 175 */       HttpURLConnection connection = (HttpURLConnection)(new URL((String)this.webhookUrl.get())).openConnection();
/* 176 */       connection.setRequestMethod("POST");
/* 177 */       connection.setRequestProperty("Content-Type", "application/json");
/* 178 */       connection.setDoOutput(true);
/* 179 */       OutputStream os = connection.getOutputStream(); 
/* 180 */       try { os.write(payload.getBytes());
/* 181 */         os.flush();
/* 182 */         if (os != null) os.close();  } catch (Throwable throwable) { if (os != null)
/* 183 */           try { os.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  connection.getResponseCode();
/* 184 */       connection.disconnect();
/* 185 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDeactivate() {
/* 190 */     class_304.method_1416(this.mc.field_1690.field_1886.method_1429(), false);
/* 191 */     if (this.sneaking && this.mc.field_1724 != null && this.mc.field_1724.method_5715()) {
/* 192 */       this.mc.field_1724.method_5660(false);
/* 193 */       this.mc.method_1562().method_52787((class_2596)new class_2848((class_1297)this.mc.field_1724, class_2848.class_2849.field_12984));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\kunna\Downloads\meteor-kez-addon-1.21.4-0.1.0 (1).jar!\kez\addon\modules\AutoSpawnerBreakerBaritone.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */