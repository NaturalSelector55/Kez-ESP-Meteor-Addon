/*     */ package kez.addon.modules;
/*     */ import meteordevelopment.meteorclient.events.render.Render3DEvent;
/*     */ import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
/*     */ import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
/*     */ import meteordevelopment.meteorclient.renderer.ShapeMode;
/*     */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*     */ import meteordevelopment.meteorclient.settings.ColorSetting;
/*     */ import meteordevelopment.meteorclient.settings.EnumSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.meteorclient.utils.Utils;
/*     */ import meteordevelopment.meteorclient.utils.render.color.Color;
/*     */ import meteordevelopment.meteorclient.utils.render.color.SettingColor;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2791;
/*     */ 
/*     */ public class KezESP2 extends Module {
/*  22 */   private final SettingGroup sgRender = this.settings.createGroup("Render");
/*     */   
/*  24 */   private final Setting<SettingColor> espColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder())
/*  25 */       .name("esp-color"))
/*  26 */       .description("ESP box color."))
/*  27 */       .defaultValue(new SettingColor(0, 200, 255, 100))
/*  28 */       .build());
/*     */ 
/*     */   
/*  31 */   private final Setting<ShapeMode> shapeMode = this.sgRender.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/*  32 */       .name("shape-mode"))
/*  33 */       .description("Box render mode."))
/*  34 */       .defaultValue(ShapeMode.Both))
/*  35 */       .build());
/*     */ 
/*     */   
/*  38 */   private final Setting<Boolean> chatFeedback = this.sgRender.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  39 */       .name("chat-feedback"))
/*  40 */       .description("Announce detections in chat."))
/*  41 */       .defaultValue(Boolean.valueOf(true)))
/*  42 */       .build());
/*     */ 
/*     */   
/*  45 */   private final Set<class_2338> detectedDeepslate = new HashSet<>();
/*     */   
/*     */   public KezESP2() {
/*  48 */     super(KezAddon.CATEGORY, "kez-esp2", "ESP for all deepslate blocks at y >= 8.");
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onChunkLoad(ChunkDataEvent event) {
/*  53 */     scanChunk((class_2791)event.chunk());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onBlockUpdate(BlockUpdateEvent event) {
/*  58 */     class_2338 pos = event.pos;
/*  59 */     class_2680 state = event.newState;
/*  60 */     boolean isDeepslate = isTargetDeepslate(state, pos.method_10264());
/*     */     
/*  62 */     if (isDeepslate && this.detectedDeepslate.add(pos)) {
/*  63 */       if (((Boolean)this.chatFeedback.get()).booleanValue()) info("§bKezESP2§f: Deepslate at §a" + pos.method_23854(), new Object[0]); 
/*  64 */     } else if (!isDeepslate) {
/*  65 */       this.detectedDeepslate.remove(pos);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void scanChunk(class_2791 chunk) {
/*  70 */     int xStart = chunk.method_12004().method_8326();
/*  71 */     int zStart = chunk.method_12004().method_8328();
/*  72 */     int yMin = chunk.method_31607();
/*  73 */     int yMax = Math.min(128, yMin + chunk.method_31605());
/*     */     
/*  75 */     for (int x = xStart; x < xStart + 16; x++) {
/*  76 */       for (int z = zStart; z < zStart + 16; z++) {
/*  77 */         for (int y = Math.max(yMin, 8); y < yMax; y++) {
/*  78 */           class_2338 pos = new class_2338(x, y, z);
/*  79 */           if (isTargetDeepslate(chunk.method_8320(pos), y) && 
/*  80 */             this.detectedDeepslate.add(pos) && ((Boolean)this.chatFeedback.get()).booleanValue()) {
/*  81 */             info("§bKezESP2§f: Deepslate at §a" + pos.method_23854(), new Object[0]);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isTargetDeepslate(class_2680 state, int y) {
/*  91 */     return (y >= 8 && y < 128 && state.method_26204() == class_2246.field_28888);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onActivate() {
/*  96 */     this.detectedDeepslate.clear();
/*  97 */     if (this.mc.field_1687 == null)
/*  98 */       return;  for (class_2791 chunk : Utils.chunks()) {
/*  99 */       scanChunk(chunk);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onRender(Render3DEvent event) {
/* 105 */     Color sideColor = new Color((Color)this.espColor.get());
/* 106 */     Color lineColor = new Color((Color)this.espColor.get());
/*     */     
/* 108 */     for (class_2338 pos : this.detectedDeepslate)
/* 109 */       event.renderer.box(pos, sideColor, lineColor, (ShapeMode)this.shapeMode.get(), 0); 
/*     */   }
/*     */ }


/* Location:              C:\Users\kunna\Downloads\meteor-kez-addon-1.21.4-0.1.0 (1).jar!\kez\addon\modules\KezESP2.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */