/*    */ package kez.addon.modules;
/*    */ 
/*    */ import kez.addon.KezAddon;
/*    */ import meteordevelopment.meteorclient.events.world.TickEvent;
/*    */ import meteordevelopment.meteorclient.settings.IntSetting;
/*    */ import meteordevelopment.meteorclient.settings.Setting;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.orbit.EventHandler;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1703;
/*    */ import net.minecraft.class_1707;
/*    */ import net.minecraft.class_1713;
/*    */ import net.minecraft.class_1802;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2350;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2846;
/*    */ 
/*    */ public class ShulkerDropper extends Module {
/* 20 */   private final Setting<Integer> delay = this.settings.getDefaultGroup().add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder())
/*    */       
/* 22 */       .name("delay"))
/* 23 */       .description("Delay between drops (in ticks)."))
/* 24 */       .defaultValue(Integer.valueOf(1)))
/* 25 */       .min(0)
/* 26 */       .max(20)
/* 27 */       .sliderMax(20)
/* 28 */       .build());
/*    */ 
/*    */   
/* 31 */   private int delayCounter = 0;
/*    */   
/*    */   public ShulkerDropper() {
/* 34 */     super(KezAddon.CATEGORY, "Shulker Dropper", "Goes to shop, buys shulkers, and drops automatically.");
/*    */   }
/*    */ 
/*    */   
/*    */   public void onActivate() {
/* 39 */     this.delayCounter = 0;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onDeactivate() {}
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   private void onTick(TickEvent.Post event) {
/* 49 */     if (this.mc.field_1724 == null)
/*    */       return; 
/* 51 */     if (this.delayCounter > 0) {
/* 52 */       this.delayCounter--;
/*    */       
/*    */       return;
/*    */     } 
/* 56 */     class_1703 handler = this.mc.field_1724.field_7512;
/* 57 */     if (!(handler instanceof class_1707)) {
/* 58 */       this.mc.field_1724.field_3944.method_45729("/shop");
/* 59 */       this.delayCounter = 20;
/*    */       
/*    */       return;
/*    */     } 
/* 63 */     class_1707 gh = (class_1707)handler;
/* 64 */     if (gh.method_17388() != 3)
/*    */       return; 
/* 66 */     if (handler.method_7611(11).method_7677().method_31574(class_1802.field_20399) && handler.method_7611(11).method_7677().method_7947() == 1) {
/* 67 */       this.mc.field_1761.method_2906(handler.field_7763, 11, 0, class_1713.field_7790, (class_1657)this.mc.field_1724);
/* 68 */       this.delayCounter = 20;
/*    */       
/*    */       return;
/*    */     } 
/* 72 */     if (handler.method_7611(17).method_7677().method_31574(class_1802.field_8545)) {
/* 73 */       this.mc.field_1761.method_2906(handler.field_7763, 17, 0, class_1713.field_7790, (class_1657)this.mc.field_1724);
/* 74 */       this.delayCounter = 20;
/*    */       
/*    */       return;
/*    */     } 
/* 78 */     if (handler.method_7611(13).method_7677().method_31574(class_1802.field_8545)) {
/* 79 */       this.mc.field_1761.method_2906(handler.field_7763, 23, 0, class_1713.field_7790, (class_1657)this.mc.field_1724);
/* 80 */       this.delayCounter = ((Integer)this.delay.get()).intValue();
/* 81 */       this.mc.field_1724.field_3944.method_52787((class_2596)new class_2846(class_2846.class_2847.field_12970, class_2338.field_10980, class_2350.field_11033));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\kunna\Downloads\meteor-kez-addon-1.21.4-0.1.0 (1).jar!\kez\addon\modules\ShulkerDropper.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */