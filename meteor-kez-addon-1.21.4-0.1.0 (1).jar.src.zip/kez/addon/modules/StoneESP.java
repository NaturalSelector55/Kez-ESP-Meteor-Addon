/*     */ package kez.addon.modules;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import kez.addon.KezAddon;
/*     */ import meteordevelopment.meteorclient.events.render.Render3DEvent;
/*     */ import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
/*     */ import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
/*     */ import meteordevelopment.meteorclient.renderer.ShapeMode;
/*     */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*     */ import meteordevelopment.meteorclient.settings.ColorSetting;
/*     */ import meteordevelopment.meteorclient.settings.EnumSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.meteorclient.utils.Utils;
/*     */ import meteordevelopment.meteorclient.utils.render.color.Color;
/*     */ import meteordevelopment.meteorclient.utils.render.color.SettingColor;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2791;
/*     */ 
/*     */ public class StoneESP extends Module {
/*  25 */   private final SettingGroup sgRender = this.settings.createGroup("Render");
/*     */   
/*  27 */   private final Setting<SettingColor> espColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder())
/*  28 */       .name("esp-color"))
/*  29 */       .description("ESP box color."))
/*  30 */       .defaultValue(new SettingColor(120, 120, 120, 100))
/*  31 */       .build());
/*     */ 
/*     */   
/*  34 */   private final Setting<ShapeMode> shapeMode = this.sgRender.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/*  35 */       .name("shape-mode"))
/*  36 */       .description("Box render mode."))
/*  37 */       .defaultValue(ShapeMode.Both))
/*  38 */       .build());
/*     */ 
/*     */   
/*  41 */   private final Setting<Boolean> chatFeedback = this.sgRender.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  42 */       .name("chat-feedback"))
/*  43 */       .description("Announce detections in chat."))
/*  44 */       .defaultValue(Boolean.valueOf(true)))
/*  45 */       .build());
/*     */ 
/*     */   
/*  48 */   private final Set<class_2338> detectedStone = new HashSet<>();
/*     */   
/*     */   public StoneESP() {
/*  51 */     super(KezAddon.CATEGORY, "stone-esp", "ESP for stone blocks below deepslate level (some false positives with lava generated stone");
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onChunkLoad(ChunkDataEvent event) {
/*  56 */     scanChunk((class_2791)event.chunk());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onBlockUpdate(BlockUpdateEvent event) {
/*  61 */     class_2338 pos = event.pos;
/*  62 */     class_2680 state = event.newState;
/*  63 */     boolean isStone = isTargetStone(state, pos.method_10264());
/*     */     
/*  65 */     if (isStone && this.detectedStone.add(pos)) {
/*  66 */       if (((Boolean)this.chatFeedback.get()).booleanValue()) info("§7StoneESP§f: Stone at §a" + pos.method_23854(), new Object[0]); 
/*  67 */     } else if (!isStone) {
/*  68 */       this.detectedStone.remove(pos);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void scanChunk(class_2791 chunk) {
/*  73 */     int xStart = chunk.method_12004().method_8326();
/*  74 */     int zStart = chunk.method_12004().method_8328();
/*  75 */     int yMin = chunk.method_31607();
/*  76 */     int yMax = Math.min(1, yMin + chunk.method_31605());
/*     */     
/*  78 */     for (int x = xStart; x < xStart + 16; x++) {
/*  79 */       for (int z = zStart; z < zStart + 16; z++) {
/*  80 */         for (int y = yMin; y < yMax; y++) {
/*  81 */           class_2338 pos = new class_2338(x, y, z);
/*  82 */           if (isTargetStone(chunk.method_8320(pos), y) && 
/*  83 */             this.detectedStone.add(pos) && ((Boolean)this.chatFeedback.get()).booleanValue()) {
/*  84 */             info("§7StoneESP§f: Stone at §a" + pos.method_23854(), new Object[0]);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isTargetStone(class_2680 state, int y) {
/*  93 */     return (y <= -1 && state.method_26204() == class_2246.field_10340);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onActivate() {
/*  98 */     this.detectedStone.clear();
/*  99 */     if (this.mc.field_1687 == null)
/* 100 */       return;  for (class_2791 chunk : Utils.chunks()) {
/* 101 */       scanChunk(chunk);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onRender(Render3DEvent event) {
/* 107 */     Color sideColor = new Color((Color)this.espColor.get());
/* 108 */     Color lineColor = new Color((Color)this.espColor.get());
/*     */     
/* 110 */     for (class_2338 pos : this.detectedStone)
/* 111 */       event.renderer.box(pos, sideColor, lineColor, (ShapeMode)this.shapeMode.get(), 0); 
/*     */   }
/*     */ }


/* Location:              C:\Users\kunna\Downloads\meteor-kez-addon-1.21.4-0.1.0 (1).jar!\kez\addon\modules\StoneESP.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */