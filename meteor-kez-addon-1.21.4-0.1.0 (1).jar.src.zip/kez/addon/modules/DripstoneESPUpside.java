/*     */ package kez.addon.modules;
/*     */ import meteordevelopment.meteorclient.events.render.Render3DEvent;
/*     */ import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
/*     */ import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
/*     */ import meteordevelopment.meteorclient.renderer.ShapeMode;
/*     */ import meteordevelopment.meteorclient.settings.BoolSetting;
/*     */ import meteordevelopment.meteorclient.settings.ColorSetting;
/*     */ import meteordevelopment.meteorclient.settings.EnumSetting;
/*     */ import meteordevelopment.meteorclient.settings.Setting;
/*     */ import meteordevelopment.meteorclient.settings.SettingGroup;
/*     */ import meteordevelopment.meteorclient.systems.modules.Module;
/*     */ import meteordevelopment.meteorclient.utils.Utils;
/*     */ import meteordevelopment.meteorclient.utils.render.color.Color;
/*     */ import meteordevelopment.meteorclient.utils.render.color.SettingColor;
/*     */ import meteordevelopment.orbit.EventHandler;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2741;
/*     */ import net.minecraft.class_2769;
/*     */ import net.minecraft.class_2791;
/*     */ 
/*     */ public class DripstoneESPUpside extends Module {
/*  25 */   private final SettingGroup sgRender = this.settings.createGroup("Render");
/*     */   
/*  27 */   private final Setting<SettingColor> espColor = this.sgRender.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder())
/*  28 */       .name("esp-color"))
/*  29 */       .description("ESP box color."))
/*  30 */       .defaultValue(new SettingColor(255, 150, 100, 100))
/*  31 */       .build());
/*     */ 
/*     */   
/*  34 */   private final Setting<ShapeMode> shapeMode = this.sgRender.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder())
/*  35 */       .name("shape-mode"))
/*  36 */       .description("Box render mode."))
/*  37 */       .defaultValue(ShapeMode.Both))
/*  38 */       .build());
/*     */ 
/*     */   
/*  41 */   private final Setting<Boolean> chatFeedback = this.sgRender.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder())
/*  42 */       .name("chat-feedback"))
/*  43 */       .description("Announce detections in chat."))
/*  44 */       .defaultValue(Boolean.valueOf(true)))
/*  45 */       .build());
/*     */ 
/*     */ 
/*     */   
/*  49 */   private final Set<class_2338> longDripstoneTips = new HashSet<>();
/*     */   
/*     */   public DripstoneESPUpside() {
/*  52 */     super(KezAddon.CATEGORY, "dripstone-esp-up", "ESP for upward dripstone (stalagmite) tips with length 8+.");
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onChunkLoad(ChunkDataEvent event) {
/*  57 */     scanChunk((class_2791)event.chunk());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onBlockUpdate(BlockUpdateEvent event) {
/*  62 */     class_2338 pos = event.pos;
/*  63 */     class_2680 state = event.newState;
/*     */     
/*  65 */     if (isDripstoneTipUp(state)) {
/*  66 */       int len = getStalagmiteLength(pos);
/*  67 */       if (len >= 8) {
/*  68 */         if (this.longDripstoneTips.add(pos) && ((Boolean)this.chatFeedback.get()).booleanValue()) {
/*  69 */           info("Long stalagmite at " + pos.method_23854() + " (length " + len + ")", new Object[0]);
/*     */         }
/*     */       } else {
/*  72 */         this.longDripstoneTips.remove(pos);
/*     */       } 
/*     */     } else {
/*  75 */       this.longDripstoneTips.remove(pos);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void scanChunk(class_2791 chunk) {
/*  80 */     int xStart = chunk.method_12004().method_8326();
/*  81 */     int zStart = chunk.method_12004().method_8328();
/*  82 */     int yMin = chunk.method_31607();
/*  83 */     int yMax = yMin + chunk.method_31605();
/*     */     
/*  85 */     for (int x = xStart; x < xStart + 16; x++) {
/*  86 */       for (int z = zStart; z < zStart + 16; z++) {
/*  87 */         for (int y = yMin; y < yMax; y++) {
/*  88 */           class_2338 pos = new class_2338(x, y, z);
/*  89 */           class_2680 state = chunk.method_8320(pos);
/*     */           
/*  91 */           if (isDripstoneTipUp(state)) {
/*  92 */             int len = getStalagmiteLength(pos);
/*  93 */             if (len >= 8 && 
/*  94 */               this.longDripstoneTips.add(pos) && ((Boolean)this.chatFeedback.get()).booleanValue()) {
/*  95 */               info("Long stalagmite at " + pos.method_23854() + " (length " + len + ")", new Object[0]);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isDripstoneTipUp(class_2680 state) {
/* 106 */     return (state.method_26204() == class_2246.field_28048 && state
/* 107 */       .method_11654((class_2769)class_2741.field_28062) == class_2350.field_11036);
/*     */   }
/*     */ 
/*     */   
/*     */   private int getStalagmiteLength(class_2338 tip) {
/* 112 */     if (this.mc.field_1687 == null) return 0; 
/* 113 */     int length = 0;
/* 114 */     class_2338 scan = tip;
/*     */     while (true) {
/* 116 */       class_2680 state = this.mc.field_1687.method_8320(scan);
/* 117 */       if (state.method_26204() == class_2246.field_28048 && state
/* 118 */         .method_11654((class_2769)class_2741.field_28062) == class_2350.field_11036) {
/* 119 */         length++;
/* 120 */         scan = scan.method_10074();
/*     */         continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 125 */     return length;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onActivate() {
/* 130 */     this.longDripstoneTips.clear();
/* 131 */     if (this.mc.field_1687 == null)
/* 132 */       return;  for (class_2791 chunk : Utils.chunks()) {
/* 133 */       scanChunk(chunk);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   private void onRender(Render3DEvent event) {
/* 139 */     Color sideColor = new Color((Color)this.espColor.get());
/* 140 */     Color lineColor = new Color((Color)this.espColor.get());
/*     */     
/* 142 */     for (class_2338 pos : this.longDripstoneTips)
/* 143 */       event.renderer.box(pos, sideColor, lineColor, (ShapeMode)this.shapeMode.get(), 0); 
/*     */   }
/*     */ }


/* Location:              C:\Users\kunna\Downloads\meteor-kez-addon-1.21.4-0.1.0 (1).jar!\kez\addon\modules\DripstoneESPUpside.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */