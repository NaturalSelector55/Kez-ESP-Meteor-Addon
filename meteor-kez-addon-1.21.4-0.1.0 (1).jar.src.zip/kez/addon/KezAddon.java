/*    */ package kez.addon;
/*    */ import kez.addon.hud.HudExample;
/*    */ import kez.addon.modules.AutoSpawnerBreakerBaritone;
/*    */ import kez.addon.modules.BoneDropper;
/*    */ import kez.addon.modules.DripstoneESP;
/*    */ import kez.addon.modules.DripstoneESPUpside;
/*    */ import kez.addon.modules.KezESP2;
/*    */ import meteordevelopment.meteorclient.addons.GithubRepo;
/*    */ import meteordevelopment.meteorclient.addons.MeteorAddon;
/*    */ import meteordevelopment.meteorclient.commands.Commands;
/*    */ import meteordevelopment.meteorclient.systems.hud.HudGroup;
/*    */ import meteordevelopment.meteorclient.systems.modules.Category;
/*    */ import meteordevelopment.meteorclient.systems.modules.Module;
/*    */ import meteordevelopment.meteorclient.systems.modules.Modules;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class KezAddon extends MeteorAddon {
/* 19 */   public static final Logger LOG = LoggerFactory.getLogger("Kez Addon");
/* 20 */   public static final Category CATEGORY = new Category("Kez Addon", class_1802.field_8077.method_7854());
/* 21 */   public static final HudGroup HUD_GROUP = new HudGroup("Kez Addon");
/*    */ 
/*    */   
/*    */   public void onInitialize() {
/* 25 */     LOG.info("Initializing Meteor Kez Addon");
/*    */ 
/*    */     
/* 28 */     Modules modules = Modules.get();
/* 29 */     modules.add((Module)new AutoSpawnerBreakerBaritone());
/* 30 */     modules.add((Module)new BoneDropper());
/* 31 */     modules.add((Module)new DripstoneESP());
/* 32 */     modules.add((Module)new DripstoneESPUpside());
/* 33 */     modules.add((Module)new KezESP());
/* 34 */     modules.add((Module)new KezESP2());
/* 35 */     modules.add((Module)new ShulkerDropper());
/* 36 */     modules.add((Module)new StoneESP());
/*    */ 
/*    */     
/* 39 */     Commands.add((Command)new CommandExample());
/*    */ 
/*    */     
/* 42 */     Hud.get().register(HudExample.INFO);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onRegisterCategories() {
/* 47 */     Modules.registerCategory(CATEGORY);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getPackage() {
/* 52 */     return "kez.addon";
/*    */   }
/*    */ 
/*    */   
/*    */   public GithubRepo getRepo() {
/* 57 */     return new GithubRepo("MeteorDevelopment", "meteor-addon-template");
/*    */   }
/*    */ }


/* Location:              C:\Users\kunna\Downloads\meteor-kez-addon-1.21.4-0.1.0 (1).jar!\kez\addon\KezAddon.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */